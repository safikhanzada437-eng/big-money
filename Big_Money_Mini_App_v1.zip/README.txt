# Big Money Mini App

Version 1 is a front-end prototype:
- Initial balance: 0 USDT
- TRC20 deposit address shown
- Home / Deposit / Withdraw / Profile
- Daily reward placeholder
- Referral placeholder
- Mobile-first dark UI

Important: this version does NOT verify blockchain deposits and does NOT send real USDT.
Real deposits/withdrawals require a secure backend and transaction verification before balances are credited.
